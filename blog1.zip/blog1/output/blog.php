<?php $page= "blog";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Domine:wght@400;500;600;700&display=swap" rel="stylesheet">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- hover master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        
        <!-- section2 -->
        <section class="section2 mt-5">
            <div class="container">
                <div class="row text-center justify-content-sm-center no-gutters">
                    <div class="col-12 m-auto">
                        <h2>All Blogs</h2>
                        <div class="col-md-4 mx-auto">
                            <div class="progress mt-2" style="height: 1.9px;">
                                <div class="progress-bar bg-gold" style="width:50%"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 mt-5 left-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img2 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 mt-5 top-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img1 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 mt-5 right-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img2 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-5 left-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img2 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 mt-5 top-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img1 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 mt-5 right-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img2 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-5 left-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img2 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 mt-5 top-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img1 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 mt-5 right-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img2 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-5 left-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img2 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 mt-5 top-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img1 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 mt-5 right-reveal">
                        <a href="blog-details.php">
                            <div class="parent">
                                <div class="bg-img2 child rounded-lg p-5">
                                    <div class="p-5 m-4"></div>
                                </div>
                            </div>
                        </a>
                        <div class="mt-4">
                            <a href="#" class="text-decoration-none text-hvr1 mr-3">
                                <i class="fa fa-user text-gold mr-1"></i>
                                <small>by Jack Blacks</small>
                            </a>
                            <span class="mr-3">
                                <i class="fa fa-clock-o text-gold mr-1"></i>
                                <small class="text-muted">55 Minutes</small>
                            </span>
                        </div>
                        <a class="text-hvr1 text-decoration-none" href="blog-details.php">
                            <h2 class="h5 mt-3">Egg salad sandwich with avocado and watercress</h2>
                        </a>
                        <p class="mt-3 text-muted">Lorem ipsum dolor sit amet, conse tetui isicing elit, sed do eiu smod tempor inci unt ut
                            labore et dol ore magna aliqu
                            enim ad minim v</p>
                    
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <a href="#" class="text-decoration-none text-dark d-flex">
                                    <span><img class="wid1 rounded-circle mr-3" src="assets/image/person.jpg"></span>
                                    <span>
                                        <h6 class="mb-0">Watsons</h6>
                                        <small class="text-muted">Editor</small>
                                    </span>
                                </a>
                            </div>
                            <div>
                                <a href="#" class="btn btn-light rounded-circle text-decoration-none">
                                    <i class="fa fa-user text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Contents 22 -->
        <section class="section2 pt-3 mt-5">
            <div class="container">
                <div class="bg-light brd2 p-5">
                    <div class="row justify-content-center py-5">
                        <div class="col-12 col-lg-8 col-xl-6 text-center left-reveal">
                            <h2>We Offer You Partnership</h2>
                            <p class="mt-4 mb-5">We love to partner with brands and products that we believe in. If you feel that your company shares values and would
                            benefit our readers, we would love to talk about working together.</p>
        
                            <a href="#" class="btn9 px-5 py-3 mt-5 bg-gold border-0">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        

        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

</body>
</html>