  
<!--footer-->
<footer class="bg-gold foot text-white mt-5">
    <div class="container">
        <div class="row pb-3 pt-5 left-reveal">
            <div class="col-12 col-md-6 col-lg-3 mt-5">
                <a class="navbar-brand text-dark" href="index.html">
                    <img class="w-100" src="assets/image/logo.png">
                </a>
                <p class="mt-4 text-white"> Carefully crafted Webflow template for blog or magazine.</p>
                <span>
                    <a href="#" class="btn btn-primary btn-sm mt-2"><i class="fa fa-facebook"></i></a>
                    <a href="#" class="btn btn-info btn-sm mt-2 ml-2"><i class="fa fa-twitter"></i></a>
                    <a href="#" class="btn btn-primary btn-sm mt-2 ml-2"><i class="fa fa-linkedin"></i></a>
                    <a href="#" class="btn btn-danger btn-sm mt-2 ml-2 border border-danger"><i class="fa fa-youtube"></i></a>
                </span>
            </div>

            <div class="col-12 col-md-6 col-lg-3 mt-5">
                <h5 class="mb-5">Navigation</h5>
                <a class="text-white hvr-icon-forward border border-left-0 border-right-0 border-bottom-0 p-3 mt-4 d-flex justify-content-between" href="#">
                    <span class="hvr-icon">Intro</span><small><small class="fa fa-chevron-right hvr-icon smll mt-2 align-self-center"></small></small>
                </a>
                <a class="text-white hvr-icon-forward border border-left-0 border-right-0 border-bottom-0 p-3 d-flex justify-content-between" href="#">
                    <span class="hvr-icon">Culture</span><small><small class="fa fa-chevron-right hvr-icon smll mt-2 align-self-center"></small></small>
                </a>
                <a class="text-white hvr-icon-forward border border-left-0 border-right-0 border-bottom-0 p-3 d-flex justify-content-between" href="#">
                    <span class="hvr-icon">Events</span><small><small class="fa fa-chevron-right hvr-icon smll mt-2 align-self-center"></small></small>
                </a>
                <a class="text-white hvr-icon-forward border border-left-0 border-right-0 border-bottom-0 p-3 d-flex justify-content-between" href="#">
                    <span class="hvr-icon">Lifestyle</span><small><small class="fa fa-chevron-right hvr-icon smll mt-2 align-self-center"></small></small>
                </a>
                <a class="text-white hvr-icon-forward border border-left-0 border-right-0 p-3 d-flex justify-content-between" href="#">
                    <span class="hvr-icon">Tech</span><small><small class="fa fa-chevron-right hvr-icon smll mt-2 align-self-center"></small></small>
                </a>
            </div>

            <div class="col-12 col-md-6 col-lg-3 mt-5">
                <h5 class="">Featured Posts</h5>
                <div class="row mt-4 pt-2">
                    <a class="col-4" href="#">
                        <div class="parent rounded-lg mt-md-0 mt-2">
                            <div class="child">
                                <img class="w-100" src="assets/image/h2-img-9-1.jpg">
                            </div>
                        </div>
                    </a>
                    <div class="col-8 pl-0 align-self-center">
                        <a class="text-white" href="#">
                            <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                        </a>
                        <p class="text-white">
                            <small><i class="fa fa-clock-o fa-lg mr-2"></i> 3min read</small>
                        </p>
                    </div>
                </div>
                <div class="row mt-1">
                    <a class="col-4" href="#">
                        <div class="parent rounded-lg mt-md-0 mt-2">
                            <img class="child w-100" src="assets/image/h2-img-9-1.jpg">
                        </div>
                    </a>
                    <div class="col-8 pl-0 align-self-center">
                        <a href="#" class="text-white">
                            <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                        </a>
                        <p class="text-white">
                            <small><i class="fa fa-clock-o fa-lg mr-2"></i> 3min read</small>
                        </p>
                    </div>
                </div>
                <div class="row mt-1">
                    <a class="col-4" href="#" class="text-dark">
                        <div class="parent rounded-lg mt-md-0 mt-2">
                            <img class="child w-100" src="assets/image/h2-img-9-1.jpg">
                        </div>
                    </a>
                    <div class="col-8 pl-0 align-self-center">
                        <a href="#" class="text-white">
                            <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                        </a>
                        <p class="text-white">
                            <small><i class="fa fa-clock-o fa-lg mr-2"></i> 3min read</small>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-3 mt-5">
                <h5>Newsletters</h5>
                <div class="mt-4 text-white">
                    <p class="text-white">New posts straight to your inbox</p>
                    <form class="">
                        <input class="form-control p-4 bg-light" type="text" name="name" placeholder="Enter Your Email">
                        <button class="btn btn-outline-light btn-lg w-100 mt-3" type="button"><small class="font-weight-bold">Subscribe</small></button>
                    </form>
                    <small>No spam ever. Read our <a href="#"><u>Privacy Policy</u></a></small>
                </div>
            </div>
        </div>
    </div>

    <hr>
    <div class="container">
        <div class="row left-reveal">
            <div class="col-12 col-md-7 mt-2 pt-1 text-lg-left text-muted">
                <p class="text-white small">
                    <small><i class="fa fa fa-lg mr-2">w</i> POWERED BY <a href="#" class="text-white">WEBFLOW</a></small> |
                    <small><i class="fa fa-heart-o fa-lg mr-2"></i> CREATED BY <a href="#" class="text-white">ELASTIC THEMES</a></small> |
                    <small><i class="fa fa-dollar fa-lg mr-2"></i> POWERED BY <a href="#" class="text-white">BY TEMPLATE</a></small>
                </p>
            </div>
            <div class="col-12 col-md-5 mt-2 pt-1 text-center text-lg-right text-muted">
                <p class="text-white small">
                    <small><a href="#" class="text-white">STYLE GUIDE</a></small>
                    <small class="ml-3"><a href="#" class="text-white">CHANGELOG</a></small>
                    <small class="ml-3"><a href="#" class="text-white">LICENSING</a></small>
                </p>
            </div>
        </div>
    </div>
</footer>

<!--scroll-top-->
<div>
    <a class="scroll-top" href="#"><i class="fa fa-angle-double-up text-white fa-lg px-2 rounded-lg py-2 bg-green"></i></a>
</div> 
   
