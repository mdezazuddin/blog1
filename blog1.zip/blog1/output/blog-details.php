<?php $page= "single-blog";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Domine:wght@400;500;600;700&display=swap" rel="stylesheet">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- hover master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        
        <!-- section2 -->
        <section class="section2 mt-4">
            <div class="container pb-5">
                <div class="row">
                    <div class="col-12 mt-md-5 col-lg-8">
                        <div class="">
                            <img class="w-100" src="assets/image/img1.jpg">
                            <h4 class="mt-3 font-weight-bold">Classics From Yesterday</h4>
                            <ul class="d-md-flex mt-3 pl-0">
                                <li class="border-0 p-0 mt-2 media">
                                    <p class="mr-2 mb-0"><i class="fa fa-user text-gold"></i> </p>
                                    <div class="media-body">
                                        <p class="mb-0"><a href="#" class="text-decoration-none text-hvr1 text-grey"> Darren Rowse</a></p>
                                    </div>
                                </li>
                                <li class="border-0 p-0 mt-2 media ml-md-4 pl-md-3">
                                    <p class="mr-2 mb-0"><i class="fa fa-clock-o text-gold"></i> </p>
                                    <div class="media-body">
                                        <p class="mb-0"><a href="#" class="text-decoration-none text-hvr1 text-grey"> April 13, 2020</a></p>
                                    </div>
                                </li>
                                <li class="border-0 p-0 mt-2 d-flex media ml-md-4 pl-md-3">
                                    <p class="mr-2 mb-0"><i class="fa fa-comment text-gold"></i> </p>
                                    <div class="media-body">
                                        <p class="mb-0"><a href="#" class="text-decoration-none text-hvr1 text-grey"> 9 Comments</a></p>
                                    </div>
                                </li>
                            </ul>
                            <h6 class="mt-4">In mattis scelerisque magna, ut tincidunt ex. Quisque nibh urna, pretium in tristique in, bibendum sed libero. Pellentesque mauris nunc, pretium non erat non, finibus tristique dui.</h6>
                            <p class="mt-3">Donec at nunc et felis vehicula imperdiet. Aliquam ac nulla id purus lacinia imperdiet commodo sit amet nunc. Interdum et malesuada fames ac ante ipsum primis in faucibus. Aenean ultricies et risus in porta. Nam finibus, nisl ut sodales ultrices, libero urna condimentum tortor, a commodo tortor tortor a sem. Donec vehicula neque vel nisl malesuada blandis.</p>
                            <blockquote class="pl-3 mt-4 py-4 ml-md-5 text-grey">
                                <i>In mattis scelerisque magna, ut tincidunt ex. Quisque nibh urna, pre in tristique in, bibendum sed libero. Pellent mauris nunc, pretium non erat non, finibus are tristique dui. Ut sed sem orci. Interdum et malesuada fames ac ante ipsum primis.</i>
                            </blockquote>
                            <p class="mt-4">Donec at nunc et felis vehicula imperdiet. Aliquam ac nulla id purus lacinia imperdiet commodo sit amet nunc. Interdum et malesuada fames ac ante ipsum primis in faucibus. Aenean ultricies et risus in porta. Nam finibus, nisl ut sodales ultrices, libero urna condimentum tortor, a commodo tortor tortor a sem. Donec vehicula neque vel nisl malesuada blandis.</p>

                            <div class="row mt-4">
                                <div class="col-md-6 pr-0">
                                    <p class="mb-2 media"><i class="fa fa-check-circle mr-2 text-gold"></i> <span class="media-body">Duis ex mi, laoreet sed aliquet et, egestas non felis.</span></p>
                                    <p class="mb-2 media"><i class="fa fa-check-circle mr-2 text-gold"></i> <span class="media-body">Duis ex mi, laoreet sed aliquet et, egestas non felis.</span></p>
                                    <p class="mb-2 media"><i class="fa fa-check-circle mr-2 text-gold"></i> <span class="media-body">Duis ex mi, laoreet sed aliquet et, egestas non felis.</span></p>
                                    <p class="mb-2 media"><i class="fa fa-check-circle mr-2 text-gold"></i> <span class="media-body">Duis ex mi, laoreet sed aliquet et, egestas non felis.</span></p>
                                </div>
                                <div class="col-md-6 pr-0">
                                    <p class="mb-2 media"><i class="fa fa-check-circle mr-2 text-gold"></i> <span class="media-body">Duis ex mi, laoreet sed aliquet et, egestas non felis.</span></p>
                                    <p class="mb-2 media"><i class="fa fa-check-circle mr-2 text-gold"></i> <span class="media-body">Duis ex mi, laoreet sed aliquet et, egestas non felis.</span></p>
                                    <p class="mb-2 media"><i class="fa fa-check-circle mr-2 text-gold"></i> <span class="media-body">Duis ex mi, laoreet sed aliquet et, egestas non felis.</span></p>
                                    <p class="mb-2 media"><i class="fa fa-check-circle mr-2 text-gold"></i> <span class="media-body">Duis ex mi, laoreet sed aliquet et, egestas non felis.</span></p>
                                </div>
                                <div class="mt-4">
                                    <img class="w-100" src="assets/image/img2.jpg">
                                </div>
                            </div>
                            <p class="mt-3">In mattis scelerisque magna, ut tincidunt ex. Quisque nibh urna, pretium in tristique in, bibendum sed libero. Pellentesque mauris nunc, pretium non erat non, finibus tristique dui. Ut sed sem orci. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
                        </div>
                    
                        <div class="d-flex justify-content-between mt-5 mb-5">
                            <div class="d-flex">
                                <i class="fa fa-pinterest text-grey mt-3"></i>
                                <a href="#" class="btn btn-light btn-sm rounded-0 mt-2 px-2 pt-1 ml-2 border">Earcare</a>
                                <a href="#" class="btn btn-light btn-sm rounded-0 mt-2 px-2 ml-2 pt-1 border">Beauty</a>
                            </div>
                            <span>
                                <a href="#" class="btn btn-light btn-sm rounded-0 mt-2 border"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="btn btn-light btn-sm rounded-0 mt-2 border"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="btn btn-light btn-sm rounded-0 mt-2 border"><i class="fa fa-linkedin"></i></a>
                            </span>
                        </div>
                        <hr>

                        <h4>1 COMMENT</h4>
                        <div class="row mt-3">
                            <div class="col-md-2 pr-md-0 mt-4">
                                <img class="w-75 rounded-circle" src="assets/image/person.jpg">
                            </div>
                            <div class="col-md-10 pl-md-0 mt-4">
                            <div class="d-flex justify-content-between">
                                <div class="navs7">
                                    <h6><a class="text-decoration-none text-hvr1 h6" href="#">WPBINGO</a></h6>
                                    <a class="text-decoration-none text-hvr1 small" href="#">May 30, 2018</a>
                                </div>
                                <div>
                                    <a href="#" class="btn btn-light bg-light border btn-sm rounded-0 mt-2 px-2 pt-1 btns8">Reply</a>
                                </div>
                            </div>
                            <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla.</p>
                            </div>
                        </div>
                        <hr>
                        <div class="row mt-3 ml-md-5 pl-md-5">
                            <div class="col-md-2 pr-md-0 mt-4">
                                <img class="w-75 rounded-circle" src="assets/image/person.jpg">
                            </div>
                            <div class="col-md-10 pl-md-0 mt-4">
                            <div class="d-flex justify-content-between">
                                <div class="navs7">
                                    <h6><a class="text-decoration-none text-hvr1 h6" href="#">WPBINGO</a></h6>
                                    <a class="text-decoration-none text-hvr1 small" href="#">May 30, 2018</a>
                                </div>
                                <div>
                                    <a href="#" class="btn btn-light bg-light border btn-sm rounded-0 mt-2 px-2 pt-1 btns8">Reply</a>
                                </div>
                            </div>
                            <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla.</p>
                            </div>
                        </div>
                        <hr>
                        <form class="mt-5" name="frmContact" id="frmContact" method="post" action="#" enctype="multipart/form-data">
                            <div class="" data-aos="fade-up" data-aos-duration="1000">
                                <h4>LEAVE A REPLY</h4>
                                <p>Your email address will not be published.
                                </p>
                                <div class="form-group mt-4">
                                    <textarea name="txtMessage" id="txtMessage" class="form-control p-2 rounded-0 bg-light shadow-none" rows="8" placeholder="Comment *"></textarea>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4 mt-3">
                                        <div class="border border-muted bg-light p-2">
                                            <input type="text" placeholder="Name *" name="txtName" id="txtName" class="form-control border-0 shadow-none bg-light">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4 mt-3">
                                        <div class="border border-muted bg-light p-2">
                                            <input type="email" placeholder="Email *" name="txtEmail" id="txtEmail" class="form-control border-0 bg-light shadow-none">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4 mt-3">
                                        <div class="border border-muted bg-light p-2">
                                            <input type="text" placeholder="Website *" name="txtName" id="txtName" class="form-control border-0 shadow-none bg-light">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mt-4">
                                    <a href="#" class="btn btn btn9 px-5 mt-3 py-3 rounded-0">POST COMMENT</a>
                                </div>
                            </div>
                        </form>


                        <!--<div id="respond" class="comment-respond">
                            <h3 id="reply-title" class="comment-reply-title"> <small><a rel="nofollow" id="cancel-comment-reply-link" href="/1#respond" style="display:none;">Click here to cancel reply.</a></small></h3>
                            <form action="http://www.[yourdomain].com/wp-comments-post.php" method="post" id="" class="comment-form">
                                <p class="form-submit">
                                    <input name="submit" type="submit" id="" value="" />
                                    <input type='hidden' name='comment_post_ID' value='1' id='comment_post_ID' />
                                    <input type='hidden' name='comment_parent' id='comment_parent' value='0' />
                                </p>
                            </form>
                        </div> #respond -->
                    </div>


                    <div class="col-12 col-lg-4 pl-md-5 mt-4 pt-2">
                        <fieldset class="text-center border" style="min-width: 100%; padding: 30px; margin: 0; border: 1px solid #ccc;">
                            <legend class="text-center" style="width: 30%;"><span class="small font-weight-bold"><small><small>ABOUT ME</small></small></span></legend>
                            <a href="#"><img class="w-50 mx-auto d-block" src="assets/image/person.jpg"></a>
                            <h5 class="mt-4">Hi! I’m Maggy.</h5>
                            <p>I create simple, delicious recipes that require 10 ingredients or less, one bowl, or 30 minutes or less to prepare.</p>
                        </fieldset>

                        <h4 class="mt-5">Featured</h4>
                        <div class="progress mt-3" style="height: 1.9px;">
                            <div class="progress-bar bg-dark" style="width:20%;"></div>
                        </div>
                        <div class="mt-4">
                            <div class="row mt-4 pt-2">
                                <a class="col-4" href="#">
                                    <div class="parent rounded-lg mt-md-0 mt-2">
                                        <div class="child">
                                            <img class="w-100" src="assets/image/img1.jpg">
                                        </div>
                                    </div>
                                </a>
                                <div class="col-8 pl-0 align-self-center">
                                    <a class="text-hvr1" href="#">
                                        <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                                    </a>
                                    <p class="text-muted">
                                        <small><i class="fa fa-clock-o mr-2"></i> 3min read</small>
                                    </p>
                                </div>
                            </div>
                            <div class="row mt-1">
                                <a class="col-4" href="#">
                                    <div class="parent rounded-lg mt-md-0 mt-2">
                                        <img class="child w-100" src="assets/image/img2.jpg">
                                    </div>
                                </a>
                                <div class="col-8 pl-0 align-self-center">
                                    <a class="text-hvr1" href="#">
                                        <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                                    </a>
                                    <p class="text-muted">
                                        <small><i class="fa fa-clock-o mr-2"></i> 3min read</small>
                                    </p>
                                </div>
                            </div>
                            <div class="row mt-1">
                                <a class="col-4" href="#">
                                    <div class="parent rounded-lg mt-md-0 mt-2">
                                        <img class="child w-100" src="assets/image/img1.jpg">
                                    </div>
                                </a>
                                <div class="col-8 pl-0 align-self-center">
                                    <a class="text-hvr1" href="#">
                                        <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                                    </a>
                                    <p class="text-muted">
                                        <small><i class="fa fa-clock-o mr-2"></i> 3min read</small>
                                    </p>
                                </div>
                            </div>
                        </div>


                        <h4 class="mt-4">Tags</h4>
                        <div class="progress mt-3" style="height: 1.9px;">
                            <div class="progress-bar bg-dark" style="width:20%;"></div>
                        </div>
                        <div class="mt-4">
                            <a class="btn btn btn8 text-black1 border border-muted mt-2" href="#">
                            Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn8 btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                        </div>

                        <h4 class="mt-5">Newsletter</h4>
                        <div class="progress mt-3" style="height: 1.9px;">
                            <div class="progress-bar bg-dark" style="width:20%;"></div>
                        </div>
                        <div class="mt-4 text-dark">
                            <p>New posts straight to your inbox</p>
                            <form class="">
                                <input class="form-control p-4 bg-light" type="text" name="name" placeholder="Enter Your Email">
                                <button class="btn9 pb-3 btn btn-warning border-0 btn-lg bg-gold w-100 mt-3 text-white" type="button"><small class="font-weight-bold">Subscribe</small></button>
                            </form>
                            <small>No spam ever. Read our <a class="text-gold" href="#"><u>Privacy Policy</u></a></small>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Contents 22 -->
        <section class="section2 pt-4">
            <div class="container">
                <div class="bg-light brd2 p-5">
                    <div class="row justify-content-center py-5">
                        <div class="col-12 col-lg-8 col-xl-6 text-center left-reveal">
                            <h2>We Offer You Partnership</h2>
                            <p class="mt-4">We love to partner with brands and products that we believe in. If you feel that your company shares values and would
                            benefit our readers, we would love to talk about working together.</p>
        
                            <a href="#" class="btn9 btn btn px-5 py-3 mt-4 border-0">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        

        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

</body>
</html>